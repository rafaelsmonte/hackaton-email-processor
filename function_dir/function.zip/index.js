const AWS = require("aws-sdk");
const AmazonCognitoIdentity = require("amazon-cognito-identity-js");
const cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();

class CustomError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
  }
}

exports.handler = async (event) => {
  console.log("event body:");
  console.log(event.body);

  try {
    let body;

    if (typeof event.body === "string") {
      try {
        body = JSON.parse(event.body);
      } catch (error) {
        return {
          statusCode: 400,
          body: JSON.stringify({ message: "Invalid JSON format" }),
        };
      }
    } else {
      body = event.body;
    }

    const { userId } = body;

    const user = await getUser(userId);

    console.log(user);
    console.log("***");
    console.log(JSON.stringify(user));
  } catch (error) {
    console.error("an error has occurred: ");
    console.error(error);
    return {
      statusCode: error.statusCode || 500,
      body: JSON.stringify({
        error: error.message || "Internal Server Error",
      }),
    };
  }
};

async function getUser(userId) {
  try {
    const params = {
      UserPoolId: process.env.USER_POOL_ID,
      Filter: `sub = "${userId}"`,
    };

    const data = await cognitoIdentityServiceProvider
      .listUsers(params)
      .promise();

    if (data.Users && data.Users.length > 0) {
      const user = data.Users[0];

      const userData = {
        Username: user.Username,
        Pool: new AmazonCognitoIdentity.CognitoUserPool({
          UserPoolId: process.env.USER_POOL_ID,
          ClientId: process.env.CLIENT_ID,
        }),
      };

      return new AmazonCognitoIdentity.CognitoUser(userData);
    }

    throw new CustomError("User not found", 404);
  } catch (error) {
    console.error("Error getting user by sub: ", error);
    throw error; // Re-throw errors for further handling
  }
}
